# THYQERON BROWSER 1.0

Projeto Android nativo inicial para celular e Android TV. Usa Android WebView e Google como pesquisa padrão. Inclui barra de endereço, voltar/avançar, início, recarregar e salvar a página atual como página inicial.

## Como gerar o APK grátis pelo GitHub
1. Crie uma conta gratuita no GitHub, se ainda não tiver.
2. Crie um repositório novo chamado `thyqeron-browser`.
3. Envie todos os arquivos desta pasta para o repositório (incluindo `.github/workflows/build.yml`).
4. Abra a aba **Actions**, selecione **Build THYQERON Browser APK** e pressione **Run workflow**.
5. Quando terminar, abra a execução e baixe o artefato `THYQERON-BROWSER-APK`. Dentro dele estará `app-debug.apk`.
6. Transfira o APK para o celular/TV e permita instalação de apps dessa origem, se o Android solicitar.

## Notas
- É um protótipo inicial: sem sincronização de contas, bloqueador de anúncios, downloads avançados ou múltiplas abas reais ainda.
- Alguns sites podem bloquear conteúdo em WebView ou exigir Chrome/DRM.
- Para publicar como app confiável, deve-se revisar segurança, permissões e assinatura de lançamento.
- A compilação requer internet para baixar dependências. O app usa internet para carregar sites.
