package com.thyqeron.browser

import android.app.Activity
import android.os.Bundle
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import android.content.SharedPreferences

class MainActivity : Activity() {
    private lateinit var web: WebView
    private lateinit var address: EditText
    private lateinit var prefs: SharedPreferences
    private val cyan = Color.rgb(73, 230, 255)
    private val bg = Color.rgb(8, 11, 20)
    private val panel = Color.rgb(18, 25, 42)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("thyqeron_browser", Context.MODE_PRIVATE)
        buildInterface()
        web.loadUrl(prefs.getString("home", "https://www.google.com") ?: "https://www.google.com")
    }

    private fun rounded(color: Int, stroke: Int = Color.TRANSPARENT): GradientDrawable = GradientDrawable().apply {
        setColor(color); cornerRadius = 18f
        if (stroke != Color.TRANSPARENT) setStroke(2, stroke)
    }

    private fun buildInterface() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg); setPadding(14, 12, 14, 8) }
        val header = TextView(this).apply {
            text = "THYQERON  /  BROWSER"; setTextColor(cyan); textSize = 18f; typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER_VERTICAL; setPadding(8, 2, 8, 10)
        }
        root.addView(header, LinearLayout.LayoutParams(-1, 42))
        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        address = EditText(this).apply {
            hint = "Pesquisar ou digitar endereço"; setHintTextColor(Color.LTGRAY); setTextColor(Color.WHITE); textSize = 16f
            singleLine = true; imeOptions = EditorInfo.IME_ACTION_GO; setPadding(14, 0, 14, 0); background = rounded(panel, cyan)
            setSelectAllOnFocus(true)
            setOnEditorActionListener { _, action, event ->
                if (action == EditorInfo.IME_ACTION_GO || event?.keyCode == KeyEvent.KEYCODE_ENTER) { navigate(address.text.toString()); true } else false
            }
        }
        bar.addView(address, LinearLayout.LayoutParams(0, 52, 1f))
        val go = button("IR") { navigate(address.text.toString()) }
        val goParams = LinearLayout.LayoutParams(64, 52); goParams.leftMargin = 8; bar.addView(go, goParams)
        root.addView(bar, LinearLayout.LayoutParams(-1, 58))

        val controls = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        controls.addView(button("←") { if (web.canGoBack()) web.goBack() }, weightParams())
        controls.addView(button("→") { if (web.canGoForward()) web.goForward() }, weightParams())
        controls.addView(button("⌂ Início") { web.loadUrl("https://www.google.com") }, weightParams())
        controls.addView(button("↻") { web.reload() }, weightParams())
        controls.addView(button("★") { prefs.edit().putString("home", web.url ?: "https://www.google.com").apply(); Toast.makeText(this, "Página salva como início", Toast.LENGTH_SHORT).show() }, weightParams())
        root.addView(controls, LinearLayout.LayoutParams(-1, 54))

        web = WebView(this).apply {
            setBackgroundColor(Color.WHITE)
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.loadsImagesAutomatically = true
            settings.javaScriptCanOpenWindowsAutomatically = false
            settings.setSupportMultipleWindows(false)
            settings.builtInZoomControls = true
            settings.displayZoomControls = false
            isFocusable = true; isFocusableInTouchMode = true
            webViewClient = object : WebViewClient() {
                override fun onPageStarted(view: WebView?, url: String?, favicon: android.graphics.Bitmap?) { address.setText(url ?: "") }
                override fun onPageFinished(view: WebView?, url: String?) { address.setText(url ?: "") }
            }
            webChromeClient = WebChromeClient()
        }
        val webParams = LinearLayout.LayoutParams(-1, 0, 1f); webParams.topMargin = 8
        root.addView(web, webParams)
        setContentView(root)
        address.setOnFocusChangeListener { v, focused -> v.background = rounded(panel, if (focused) Color.WHITE else cyan) }
    }

    private fun weightParams() = LinearLayout.LayoutParams(0, 48, 1f).apply { setMargins(3, 2, 3, 2) }
    private fun button(label: String, action: () -> Unit) = Button(this).apply {
        text = label; textSize = 14f; isAllCaps = false; setTextColor(Color.WHITE); background = rounded(panel, cyan)
        isFocusable = true; isFocusableInTouchMode = true; setOnClickListener { action() }
        setOnFocusChangeListener { v, focused -> v.background = rounded(if (focused) Color.rgb(28, 48, 67) else panel, if (focused) Color.WHITE else cyan) }
    }

    private fun navigate(raw: String) {
        var input = raw.trim()
        if (input.isEmpty()) return
        val url = when {
            input.startsWith("https://") || input.startsWith("http://") -> input
            input.contains(".") && !input.contains(" ") -> "https://$input"
            else -> "https://www.google.com/search?q=" + java.net.URLEncoder.encode(input, "UTF-8")
        }
        web.loadUrl(url)
        web.requestFocus()
    }

    override fun onBackPressed() {
        if (::web.isInitialized && web.canGoBack()) web.goBack() else super.onBackPressed()
    }
}
